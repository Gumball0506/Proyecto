-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-08-2024 a las 05:45:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto_integrador`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `ID_Admin` int(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Correo` varchar(255) NOT NULL,
  `Contraseña` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`ID_Admin`, `Nombre`, `Correo`, `Contraseña`) VALUES
(1, 'Gil', 'Haroldotiz@outlook.es', 'abc');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calendario`
--

CREATE TABLE `calendario` (
  `id` int(11) NOT NULL,
  `ID_Proyecto` int(11) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `fecha_evento` date NOT NULL,
  `url_registro` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `ID_Comentario` int(11) NOT NULL,
  `ID_Proyecto` int(11) DEFAULT NULL,
  `Comentario` text NOT NULL,
  `Fecha_Comentario` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `ID_Estado` int(11) NOT NULL,
  `Nombre` enum('Actual','Antiguo') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`ID_Estado`, `Nombre`) VALUES
(1, 'Actual'),
(2, 'Antiguo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facultad`
--

CREATE TABLE `facultad` (
  `ID_Facultad` int(11) NOT NULL,
  `Nombre` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `facultad`
--

INSERT INTO `facultad` (`ID_Facultad`, `Nombre`) VALUES
(1, 'Facultad de Administración'),
(2, 'Facultad de Ciencias Económicas'),
(3, 'Facultad de Ciencias Financieras y Contables'),
(4, 'Facultad de Ciencias Naturales y Matemática'),
(5, 'Facultad de Ciencias Sociales'),
(6, 'Facultad de Derecho y Ciencia Política'),
(7, 'Facultad de Educación'),
(8, 'Facultad de Enfermería'),
(9, 'Facultad de Humanidades'),
(10, 'Facultad de Ingeniería Civil'),
(11, 'Facultad de Ingeniería de Sistemas y Computación'),
(12, 'Facultad de Ingeniería Electrónica e Informática'),
(13, 'Facultad de Ingeniería Geográfica, Ambiental y Ecoturismo'),
(14, 'Facultad de Ingeniería Industrial y de Sistemas'),
(15, 'Facultad de Medicina'),
(16, 'Facultad de Odontología'),
(17, 'Facultad de Oceanografía, Pesquería, Ciencias Alimentarias y Acuicultura'),
(18, 'Facultad de Psicología'),
(19, 'Facultad de Arquitectura y Urbanismo'),
(20, 'Facultad de Tecnología Médica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `page_views`
--

CREATE TABLE `page_views` (
  `id` int(11) NOT NULL,
  `page_name` varchar(255) NOT NULL,
  `view_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE `proyectos` (
  `ID_Proyecto` int(11) NOT NULL,
  `ID_Admin` int(11) DEFAULT NULL,
  `ID_Estado` int(11) DEFAULT NULL,
  `Titulo` varchar(255) NOT NULL,
  `descripcion` varchar(600) NOT NULL,
  `Foto` longblob DEFAULT NULL,
  `Fecha_Inicio` date NOT NULL,
  `Fecha_Publicacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `url_registro` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `proyectos`
--
DELIMITER $$
CREATE TRIGGER `after_project_insert` AFTER INSERT ON `proyectos` FOR EACH ROW BEGIN
    INSERT INTO calendario (ID_Proyecto, titulo, fecha_evento, url_registro) 
    VALUES (NEW.ID_Proyecto, NEW.Titulo, NEW.Fecha_Inicio, NEW.url_registro);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_proyectos` AFTER UPDATE ON `proyectos` FOR EACH ROW BEGIN
    IF NEW.ID_Estado = '2' THEN
        -- Insertar en proyectos_antiguos si aún no existe
        INSERT INTO proyectos_antiguos (ID_Proyecto, Titulo, Descripcion, Foto, Fecha_Publicacion, Estado)
        SELECT NEW.ID_Proyecto, NEW.Titulo, NEW.Descripcion, NEW.Foto, NEW.Fecha_Publicacion, NEW.ID_Estado
        FROM proyectos
        WHERE proyectos.ID_Proyecto = NEW.ID_Proyecto
        AND NOT EXISTS (
            SELECT 1 FROM proyectos_antiguos
            WHERE proyectos_antiguos.ID_Proyecto = NEW.ID_Proyecto
        );
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_project_update` BEFORE UPDATE ON `proyectos` FOR EACH ROW BEGIN
  IF OLD.ID_Estado = 1 THEN
    SET NEW.ID_Estado = 2;
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos_alumnos`
--

CREATE TABLE `proyectos_alumnos` (
  `ID_ProyectoA` int(11) NOT NULL,
  `Titulo_Proyecto` varchar(40) NOT NULL,
  `Nombres_Apellidos` varchar(255) DEFAULT NULL,
  `Codigo_alumno` int(10) NOT NULL,
  `Descripcion` varchar(300) DEFAULT NULL,
  `Correo_Electronico` varchar(100) DEFAULT NULL,
  `Archivo_Proyecto` longblob DEFAULT NULL,
  `ID_Tipo_Archivo` int(11) DEFAULT NULL,
  `ID_Facultad` int(11) DEFAULT NULL,
  `Numero_telefono` int(10) NOT NULL,
  `Proceso` enum('Aceptado','Rechazado','Proceso') DEFAULT 'Proceso',
  `Fecha_Envio` date DEFAULT curdate(),
  `ID_Admin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos_antiguos`
--

CREATE TABLE `proyectos_antiguos` (
  `ID_Antiguos` int(11) NOT NULL,
  `ID_Proyecto` int(11) DEFAULT NULL,
  `Titulo` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(300) DEFAULT NULL,
  `Foto` longblob DEFAULT NULL,
  `Fecha_Publicacion` date DEFAULT NULL,
  `Estado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_archivo`
--

CREATE TABLE `tipo_archivo` (
  `ID_Tipo_Archivo` int(11) NOT NULL,
  `Tipo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_archivo`
--

INSERT INTO `tipo_archivo` (`ID_Tipo_Archivo`, `Tipo`) VALUES
(1, 'PDF'),
(2, 'Word Document (.docx)'),
(3, 'Word Document (.doc)'),
(4, 'PowerPoint Presentation (.pptx)'),
(5, 'PowerPoint Presentation (.ppt)'),
(6, 'Text File (.txt)'),
(7, 'Image File (.jpg)'),
(8, 'Image File (.png)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vistas`
--

CREATE TABLE `vistas` (
  `ID_Vista` int(11) NOT NULL,
  `ID_Proyecto` int(11) NOT NULL,
  `fecha_vista` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Disparadores `vistas`
--
DELIMITER $$
CREATE TRIGGER `after_insert_vistas` AFTER INSERT ON `vistas` FOR EACH ROW BEGIN
    DECLARE proyecto_id INT;
    SET proyecto_id = NEW.ID_Proyecto;

    -- Incrementar el contador de vistas para el proyecto correspondiente
    INSERT INTO vistas_totales (ID_Proyecto, total_vistas)
    VALUES (proyecto_id, 1)
    ON DUPLICATE KEY UPDATE total_vistas = total_vistas + 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vistas_totales`
--

CREATE TABLE `vistas_totales` (
  `ID_Proyecto` int(11) NOT NULL,
  `total_vistas` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`ID_Admin`),
  ADD UNIQUE KEY `Correo` (`Correo`);

--
-- Indices de la tabla `calendario`
--
ALTER TABLE `calendario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ID_Proyecto` (`ID_Proyecto`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`ID_Comentario`),
  ADD KEY `fk_comentarios_proyectos` (`ID_Proyecto`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`ID_Estado`),
  ADD UNIQUE KEY `Nombre` (`Nombre`);

--
-- Indices de la tabla `facultad`
--
ALTER TABLE `facultad`
  ADD PRIMARY KEY (`ID_Facultad`);

--
-- Indices de la tabla `page_views`
--
ALTER TABLE `page_views`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`ID_Proyecto`),
  ADD KEY `ID_Estado` (`ID_Estado`),
  ADD KEY `ID_Admin` (`ID_Admin`) USING BTREE;

--
-- Indices de la tabla `proyectos_alumnos`
--
ALTER TABLE `proyectos_alumnos`
  ADD PRIMARY KEY (`ID_ProyectoA`),
  ADD KEY `ID_Tipo_Archivo` (`ID_Tipo_Archivo`),
  ADD KEY `ID_Facultad` (`ID_Facultad`),
  ADD KEY `ID_Admin` (`ID_Admin`);

--
-- Indices de la tabla `proyectos_antiguos`
--
ALTER TABLE `proyectos_antiguos`
  ADD PRIMARY KEY (`ID_Antiguos`),
  ADD KEY `fk_proyectos` (`ID_Proyecto`),
  ADD KEY `fk_estado` (`Estado`);

--
-- Indices de la tabla `tipo_archivo`
--
ALTER TABLE `tipo_archivo`
  ADD PRIMARY KEY (`ID_Tipo_Archivo`);

--
-- Indices de la tabla `vistas`
--
ALTER TABLE `vistas`
  ADD PRIMARY KEY (`ID_Vista`),
  ADD KEY `vistas_ibfk_1` (`ID_Proyecto`);

--
-- Indices de la tabla `vistas_totales`
--
ALTER TABLE `vistas_totales`
  ADD PRIMARY KEY (`ID_Proyecto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `ID_Admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `calendario`
--
ALTER TABLE `calendario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `ID_Comentario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estado`
--
ALTER TABLE `estado`
  MODIFY `ID_Estado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `page_views`
--
ALTER TABLE `page_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  MODIFY `ID_Proyecto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `proyectos_alumnos`
--
ALTER TABLE `proyectos_alumnos`
  MODIFY `ID_ProyectoA` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proyectos_antiguos`
--
ALTER TABLE `proyectos_antiguos`
  MODIFY `ID_Antiguos` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `vistas`
--
ALTER TABLE `vistas`
  MODIFY `ID_Vista` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `calendario`
--
ALTER TABLE `calendario`
  ADD CONSTRAINT `calendario_ibfk_1` FOREIGN KEY (`ID_Proyecto`) REFERENCES `proyectos` (`ID_Proyecto`) ON DELETE CASCADE;

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `fk_comentarios_proyectos` FOREIGN KEY (`ID_Proyecto`) REFERENCES `proyectos` (`ID_Proyecto`) ON DELETE CASCADE;

--
-- Filtros para la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD CONSTRAINT `ID_Estado` FOREIGN KEY (`ID_Estado`) REFERENCES `estado` (`ID_Estado`) ON DELETE SET NULL,
  ADD CONSTRAINT `proyectos_ibfk_1` FOREIGN KEY (`ID_Admin`) REFERENCES `administrador` (`ID_Admin`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `proyectos_alumnos`
--
ALTER TABLE `proyectos_alumnos`
  ADD CONSTRAINT `proyectos_alumnos_ibfk_1` FOREIGN KEY (`ID_Tipo_Archivo`) REFERENCES `tipo_archivo` (`ID_Tipo_Archivo`),
  ADD CONSTRAINT `proyectos_alumnos_ibfk_2` FOREIGN KEY (`ID_Facultad`) REFERENCES `facultad` (`ID_Facultad`),
  ADD CONSTRAINT `proyectos_alumnos_ibfk_3` FOREIGN KEY (`ID_Admin`) REFERENCES `administrador` (`ID_Admin`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `proyectos_antiguos`
--
ALTER TABLE `proyectos_antiguos`
  ADD CONSTRAINT `fk_proyectos` FOREIGN KEY (`ID_Proyecto`) REFERENCES `proyectos` (`ID_Proyecto`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `proyectos_antiguos_ibfk_1` FOREIGN KEY (`Estado`) REFERENCES `estado` (`ID_Estado`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `vistas`
--
ALTER TABLE `vistas`
  ADD CONSTRAINT `vistas_ibfk_1` FOREIGN KEY (`ID_Proyecto`) REFERENCES `proyectos` (`ID_Proyecto`) ON DELETE CASCADE;

--
-- Filtros para la tabla `vistas_totales`
--
ALTER TABLE `vistas_totales`
  ADD CONSTRAINT `fk_proyecto_vistas` FOREIGN KEY (`ID_Proyecto`) REFERENCES `proyectos` (`ID_Proyecto`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
